﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Myname;
            Myname = textBox1.Text;

            label1.Text = "Hello" + Myname;


            DialogResult dialogResult = MessageBox.Show("Are you Sure?",  "Question", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                MessageBox.Show("Your name is " + label1.Text);
            }
            else if (dialogResult == DialogResult.No)
            {
                this.Close();
            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //textBox1.Text = "Hello";
        }



        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
